﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace PRG282_Project.DataLayer
{
    internal class DataHandler
    {
        public DataHandler()
        { }

        public string conn = @"Server =JUSTINLAPTOP\SQLEXPRESS02; Initial Catalog = StudentDB  ; Integrated Security =SSPI";

        

        public DataTable GetStudentTable()
        {
            string query = @"Select * from Students";

            SqlDataAdapter adapter = new SqlDataAdapter(query,conn);

            DataTable dt = new DataTable();

            adapter.Fill(dt);
            return dt;
        }
    }
}
